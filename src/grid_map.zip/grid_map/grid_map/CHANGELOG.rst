^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.0 (2025-09-14)
------------------

2.3.0 (2024-07-29)
------------------

2.2.0 (2024-07-23)
------------------
* Merge pull request `#443 <https://github.com/ANYbotics/grid_map/issues/443>`_ from Ryanf55/update-maintainers
  Add Ryan as maintainer, remove Steve
* Add Ryan as maintainer, remove Steve
* Merge pull request `#420 <https://github.com/ANYbotics/grid_map/issues/420>`_ from Ryanf55/enfore-cpp17
  Enfore C++17
* Enfore C++17
* Contributors: Ryan, Ryan Friedman

2.1.0 (2022-11-08)
------------------

2.0.0 (2022-09-13)
------------------
* fix: build error on jammy
* Initial ROS2 port
* Contributors: Maximilian Wulf, Steve Macenski

1.6.2 (2019-10-14)
------------------

1.6.1 (2019-02-27)
------------------
* Updated author e-mail address.
* Contributors: Peter Fankhauser

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------

1.4.2 (2017-01-24)
------------------

1.4.1 (2016-10-23)
------------------
* Added new grid_map_pcl package.
* Contributors: Peter Fankhauser, Dominic Jud

1.4.0 (2016-08-22)
------------------
* Added new package grid_map_rviz_plugin.
* Contributors: Peter Fankhauser

1.3.3 (2016-05-10)
------------------
* Release for ROS Kinetic.
* Contributors: Peter Fankhauser

1.3.2 (2016-05-10)
------------------

1.3.1 (2016-05-10)
------------------

1.3.0 (2016-04-26)
------------------
* Separated OpenCV to grid map conversions to grid_map_cv package. The new methods
  are more generalized, faster, and can be used without ROS message types.
* Contributors: Peter Fankhauser

1.2.0 (2016-03-03)
------------------
* Added new package grid_map as metapackage (`#34 <https://github.com/anybotics/grid_map/issues/34>`_).
