^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package grid_map_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.4.0 (2025-09-14)
------------------

2.3.0 (2024-07-29)
------------------

2.2.0 (2024-07-23)
------------------
* Merge pull request `#443 <https://github.com/ANYbotics/grid_map/issues/443>`_ from Ryanf55/update-maintainers
  Add Ryan as maintainer, remove Steve
* Add Ryan as maintainer, remove Steve
* Contributors: Ryan, Ryan Friedman

2.1.0 (2022-11-08)
------------------

2.0.0 (2022-09-13)
------------------
* Initial ROS2 port
* Contributors: Steve Macenski

1.6.2 (2019-10-14)
------------------

1.6.1 (2019-02-27)
------------------
* Merge remote-tracking branch 'origin/master' into fix/melodic
* Merge pull request `#198 <https://github.com/ANYbotics/grid_map/issues/198>`_ from ANYbotics/feature/extend_process_file_srv
  Extend ProcessFile.srv to include topic_name field.
* Restore single topic_name field, as discussed with Peter.
* Update ProcessFile.srv
* Extend ProcessFile.srv to include topic_name field.
* Updated author e-mail address.
* Contributors: Marco Tranzatto, MarcoSuetterlin, Peter Fankhauser, Péter Fankhauser

1.6.0 (2017-11-24)
------------------

1.5.2 (2017-07-25)
------------------

1.5.1 (2017-07-25)
------------------

1.5.0 (2017-07-18)
------------------

1.4.2 (2017-01-24)
------------------

1.4.1 (2016-10-23)
------------------

1.4.0 (2016-08-22)
------------------

1.3.3 (2016-05-10)
------------------
* Release for ROS Kinetic.
* Contributors: Peter Fankhauser

1.3.2 (2016-05-10)
------------------

1.3.1 (2016-05-10)
------------------

1.3.0 (2016-04-26)
------------------

1.2.0 (2016-03-03)
------------------
* [grid_map_msgs] package exports
* Contributors: Daniel Stonier

1.1.3 (2016-01-11)
------------------

1.1.2 (2016-01-11)
------------------
* Should fix errors on build server regarding Eigen3 and visualization_msgs dependencies.

1.1.1 (2016-01-11)
------------------

1.1.0 (2016-01-08)
-------------------
* added new srv definition for processing of grid map files
* general improvements and bugfixes

1.0.0 (2015-11-20)
-------------------
* release for Springer ROS Book Chapter
